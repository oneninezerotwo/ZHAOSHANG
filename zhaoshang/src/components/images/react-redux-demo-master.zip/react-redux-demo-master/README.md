# react-redux-demo
A demo describes how redux changes its store data when working with react. 


# 在终端运行命令
npm run webpack

# 新打开一个终端窗口运行命令
npm start
